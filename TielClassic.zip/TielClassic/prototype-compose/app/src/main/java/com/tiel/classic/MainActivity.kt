package com.tiel.classic

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiel.classic.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream

private val Accent = Color(0xFF4ADE80)
private val Bg = Color(0xFF0E1116)
private val Card = Color(0xFF161B22)
private val scheme = darkColorScheme(primary = Accent, onPrimary = Color(0xFF05260F), background = Bg,
    surface = Card, onSurface = Color(0xFFE6EDF3), surfaceVariant = Card, secondary = Accent)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize(), color = Bg) { App() } } }
    }
}

class AppState(val ctx: Context) {
    val paths = Paths(ctx)
    private val prefs = ctx.getSharedPreferences("tiel", 0)
    var versions by mutableStateOf(VersionStore.list(paths))
    var selected by mutableStateOf(prefs.getString("ver", null))
    var user by mutableStateOf(prefs.getString("user", "Player") ?: "Player")
    var ram by mutableStateOf(prefs.getInt("ram", 1536))
    var status by mutableStateOf("")
    fun refresh() { versions = VersionStore.list(paths); if (selected !in versions) selected = versions.firstOrNull() }
    fun save() = prefs.edit().putString("ver", selected).putString("user", user).putInt("ram", ram).apply()
}

@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val s = remember { AppState(ctx).also { it.refresh() } }
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("▶" to "Play", "🧩" to "Mods", "☁" to "Cloud", "⚙" to "Setup")
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Card) {
            tabs.forEachIndexed { i, (ic, label) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(ic, fontSize = 18.sp) },
                    label = { Text(label) }, colors = NavigationBarItemDefaults.colors(indicatorColor = Color(0xFF1F3B2A)))
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp).fillMaxSize()) {
            Text("TielClassic", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Accent, modifier = Modifier.padding(top = 16.dp, bottom = 12.dp))
            when (tab) { 0 -> PlayScreen(s); 1 -> ModsScreen(s); 2 -> CloudScreen(s); else -> SetupScreen(s) }
        }
    }
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Card, RoundedCornerShape(16.dp)).padding(16.dp), content = content)

@Composable
fun PlayScreen(s: AppState) {
    val scope = rememberCoroutineScope()
    var warn by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            s.status = runCatching { withContext(Dispatchers.IO) { VersionStore.importZip(s.ctx, s.paths, uri) } }
                .fold({ s.selected = it; s.refresh(); "Imported $it" }, { "Import failed: ${it.message}" })
        }
    }
    if (warn) AlertDialog(onDismissRequest = { warn = false },
        title = { Text("⚠️ Supply your own files") },
        text = { Text("WARNING: ⚠️ IF YOU DON'T SUPPLY YOUR OWN JAR FILES THAT MEANS YOU ARE STEALING FROM Mojang™ OR Microsoft®.\n\nOnly import a version .jar and .json from a Minecraft copy you own (for example from your MultiMC/official launcher).") },
        confirmButton = { TextButton({ warn = false; picker.launch(arrayOf("application/zip", "application/octet-stream")) }) { Text("I own it, continue") } },
        dismissButton = { TextButton({ warn = false }) { Text("Cancel") } })

    Panel {
        Text("Version", color = Color.Gray, fontSize = 12.sp)
        var open by remember { mutableStateOf(false) }
        Box {
            OutlinedButton({ open = true }, Modifier.fillMaxWidth()) { Text(s.selected ?: "No version imported") }
            DropdownMenu(open, { open = false }) {
                s.versions.forEach { v -> DropdownMenuItem({ Text(v) }, { s.selected = v; s.save(); open = false }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton({ warn = true }, Modifier.fillMaxWidth()) { Text("Import version zip (.jar + .json)") }
    }
    Panel {
        Text("Offline account", color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(s.user, { s.user = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(16); s.save() },
            singleLine = true, modifier = Modifier.fillMaxWidth())
    }
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Mod loader", fontWeight = FontWeight.SemiBold)
                Text("Risugami's ModLoader (infdev–1.6) or latest Cleanroom (1.12.x)", color = Color.Gray, fontSize = 12.sp)
            }
            Button(onClick = {
                val v = s.selected ?: return@Button
                scope.launch {
                    s.status = "Searching loader…"
                    s.status = runCatching {
                        withContext(Dispatchers.IO) {
                            val plan = ModLoaders.find(v); s.status = "Installing ${plan.name}…"
                            ModLoaders.install(s.paths, v, plan) { progress = it }; plan.name
                        }
                    }.fold({ "Installed $it" }, { "Loader failed: ${it.message}" })
                }
            }, enabled = s.selected != null) { Text("Install") }
        }
    }
    if (progress in 0.01f..0.99f) LinearProgressIndicator({ progress }, Modifier.fillMaxWidth())
    Spacer(Modifier.weight(1f))
    if (s.status.isNotEmpty()) Text(s.status, color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
    Button(onClick = {
        s.save()
        s.ctx.startActivity(Intent(s.ctx, GameActivity::class.java).putExtra("version", s.selected).putExtra("user", s.user).putExtra("ram", s.ram))
    }, enabled = s.selected != null, modifier = Modifier.fillMaxWidth().height(56.dp).padding(bottom = 4.dp), shape = RoundedCornerShape(14.dp)) {
        Text("PLAY", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ModsScreen(s: AppState) {
    val v = s.selected
    if (v == null) { Text("Import a version first.", color = Color.Gray); return }
    var files by remember { mutableStateOf(s.paths.mods(v).listFiles()?.toList() ?: emptyList()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "mod.jar"
            s.ctx.contentResolver.openInputStream(uri)?.use { i -> File(s.paths.mods(v), name).outputStream().use { i.copyTo(it) } }
            files = s.paths.mods(v).listFiles()?.toList() ?: emptyList()
        }
    }
    Button({ picker.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("+ Install mod from file") }
    Text("Mods for $v (${files.size})", color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
    LazyColumn { items(files) { f ->
        val off = f.name.endsWith(".disabled")
        Panel { Row(verticalAlignment = Alignment.CenterVertically) {
            Text(f.name.removeSuffix(".disabled"), Modifier.weight(1f), color = if (off) Color.Gray else Color.White)
            Switch(!off, { on ->
                f.renameTo(File(f.parentFile, if (on) f.name.removeSuffix(".disabled") else f.name + ".disabled"))
                files = s.paths.mods(v).listFiles()?.toList() ?: emptyList()
            })
            TextButton({ f.delete(); files = s.paths.mods(v).listFiles()?.toList() ?: emptyList() }) { Text("✕") }
        } }
    } }
}

private fun open(ctx: Context, url: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

@Composable
fun CloudScreen(s: AppState) {
    var sub by remember { mutableIntStateOf(0) }
    TabRow(sub, containerColor = Bg, contentColor = Accent) {
        listOf("Modpacks", "Mods").forEachIndexed { i, t -> Tab(sub == i, { sub = i }, text = { Text(t) }) }
    }
    Spacer(Modifier.height(8.dp))
    if (sub == 0) Modpacks(s) else CloudMods(s)
}

@Composable
fun Modpacks(s: AppState) {
    val scope = rememberCoroutineScope()
    var target by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val v = s.selected
        if (uri != null && v != null) scope.launch {
            s.status = runCatching { withContext(Dispatchers.IO) { extractPack(s, v, uri) } }
                .fold({ "Pack installed ($it files) into $v" }, { "Pack failed: ${it.message}" })
        }
    }
    val packs = listOf(
        Triple("Better Than Adventure (BTA)", "Beta 1.7.3 based. Own jar not required for the pack itself.", "https://www.betterthanadventure.net/"),
        Triple("The 1.12.2 Pack", "Large curated 1.12.2 CurseForge pack.", "https://www.curseforge.com/minecraft/modpacks/the-1122-pack"))
    Text("1) Open the page and download the pack zip.  2) Pick a version, then import the zip.", color = Color.Gray, fontSize = 12.sp)
    packs.forEach { (n, d, u) -> Panel {
        Text(n, fontWeight = FontWeight.SemiBold); Text(d, color = Color.Gray, fontSize = 12.sp)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ open(s.ctx, u) }) { Text("Open page") }
            Button({ picker.launch(arrayOf("application/zip", "application/octet-stream")) }, enabled = s.selected != null) { Text("Import pack") }
        }
    } }
    Text(s.status, color = Color.Gray, fontSize = 12.sp)
}

private fun extractPack(s: AppState, version: String, uri: Uri): Int {
    val base = s.paths.gameDir(version).canonicalFile; var n = 0
    s.ctx.contentResolver.openInputStream(uri)!!.use { ZipInputStream(it).use { z ->
        while (true) {
            val e = z.nextEntry ?: break
            if (e.isDirectory) continue
            val out = File(base, e.name.removePrefix("overrides/").removePrefix("minecraft/")).canonicalFile
            if (!out.path.startsWith(base.path)) continue // zip-slip guard
            out.parentFile?.mkdirs(); out.outputStream().use { o -> z.copyTo(o) }; n++
        }
    } }
    return n
}

@Composable
fun CloudMods(s: AppState) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<Hit>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("Search Modrinth (filtered to ${s.selected ?: "any version"})") }
    fun search() = scope.launch {
        busy = true
        runCatching { withContext(Dispatchers.IO) { Modrinth.search(q, s.selected) } }
            .onSuccess { hits = it; msg = "${it.size} results" }.onFailure { msg = "Search failed: ${it.message}" }
        busy = false
    }
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search mods…") },
        trailingIcon = { TextButton({ search() }) { Text("Go") } })
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
        AssistChip({ open(s.ctx, "https://modrinth.com/mods") }, { Text("Modrinth") })
        AssistChip({ open(s.ctx, "https://www.curseforge.com/minecraft/mc-mods") }, { Text("CurseForge") })
        AssistChip({ open(s.ctx, "https://legacy.curseforge.com/minecraft/mc-mods") }, { Text("Legacy CF") })
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    Text(msg, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
    LazyColumn { items(hits) { h -> Panel { Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(h.title, fontWeight = FontWeight.SemiBold)
            Text(h.desc, color = Color.Gray, fontSize = 12.sp, maxLines = 2)
        }
        Button({
            val v = s.selected ?: run { msg = "Import a version first"; return@Button }
            scope.launch { msg = runCatching { withContext(Dispatchers.IO) { Modrinth.install(s.paths, h, v) {} } }
                .fold({ "Installed $it" }, { "Failed: ${it.message}" }) }
        }) { Text("Get") }
    } } } }
}

@Composable
fun SetupScreen(s: AppState) {
    val scope = rememberCoroutineScope()
    var done by remember { mutableStateOf(RuntimeInstaller.libs.count { RuntimeInstaller.isInstalled(s.paths, it) }) }
    var cur by remember { mutableStateOf("") }
    var p by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    val total = RuntimeInstaller.libs.size
    Panel {
        Text("Runtime libraries", fontWeight = FontWeight.SemiBold)
        Text("LWJGL and the Java libraries Minecraft needs ($done/$total installed).", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator({ (done + p) / total }, Modifier.fillMaxWidth())
        if (busy) Text(cur, fontSize = 12.sp, color = Color.Gray)
        Button({
            busy = true
            scope.launch {
                withContext(Dispatchers.IO) {
                    RuntimeInstaller.libs.filter { !RuntimeInstaller.isInstalled(s.paths, it) }.forEach { l ->
                        cur = l.name; p = 0f
                        runCatching { RuntimeInstaller.install(s.paths, l) { p = it } }
                        done = RuntimeInstaller.libs.count { RuntimeInstaller.isInstalled(s.paths, it) }
                    }
                }
                busy = false; p = 0f
            }
        }, enabled = !busy && done < total, modifier = Modifier.padding(top = 8.dp)) { Text(if (done == total) "All installed" else "Install all") }
    }
    Panel {
        Text("Memory: ${s.ram} MB", fontWeight = FontWeight.SemiBold)
        Slider(s.ram.toFloat(), { s.ram = (it / 128).toInt() * 128; s.save() }, valueRange = 512f..3072f)
        Text("Engine: " + if (Engine.available) "PojavLauncher engine loaded ✓" else "not bundled (see README)", color = Color.Gray, fontSize = 12.sp)
    }
    var credits by remember { mutableStateOf(false) }
    OutlinedButton({ credits = true }, Modifier.fillMaxWidth()) { Text("Credits") }
    if (credits) CreditsDialog { credits = false }
}

@Composable
fun CreditsDialog(onClose: () -> Unit) = AlertDialog(onDismissRequest = onClose,
    title = { Text("Credits") },
    text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(CREDITS_TEXT, fontSize = 13.sp) } },
    confirmButton = { TextButton(onClose) { Text("Close") } })

private const val CREDITS_TEXT = """TielClassic: created by tielbirb

Engine
- MojoLauncher (LGPL-3.0): engine and runtime
- PojavLauncher Team (LGPL-3.0): the project MojoLauncher is based on
- Boardwalk by zhuowei

Multiplayer
- Terracotta by burningtnt, built on EasyTier

Engine components
Holy GL4ES, OpenJDK, GLFW, SDL, LWJGL, mojoexec, Mesa 3D, pro-grade, bhook, Authlib-Injector, OpenAL Soft, oboe

Services
Modrinth, CurseForge, Cleanroom, Risugami's ModLoader, Better Than Adventure, The 1.12.2 Pack

Not affiliated with Mojang or Microsoft. Supply your own game files."""
