package com.tiel.classic

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import com.tiel.classic.core.Engine
import com.tiel.classic.core.Paths

class GameActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val v = intent.getStringExtra("version")!!; val user = intent.getStringExtra("user")!!
        val tv = TextView(this).apply { setTextColor(-1); text = "Starting $v…"; setPadding(48, 48, 48, 48) }
        setContentView(tv)
        Thread {
            val args = Engine.buildArgs(Paths(this), v, user, intent.getIntExtra("ram", 1536))
            Engine.launch(this, Paths(this), v, args) { m -> runOnUiThread { tv.append("\n$m") } }.onFailure { e -> runOnUiThread { tv.text = "Launch failed:\n${e.message}" } }
        }.start()
    }
}
