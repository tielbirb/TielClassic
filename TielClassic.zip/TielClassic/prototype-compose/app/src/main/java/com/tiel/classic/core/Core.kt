package com.tiel.classic.core

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID
import java.util.zip.ZipInputStream

object Net {
    private const val UA = "TielClassic/1.0 (android launcher)"
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA); c.connectTimeout = 15000; c.readTimeout = 30000
        return c.inputStream.bufferedReader().use { it.readText() }
    }
    fun download(url: String, out: File, onProgress: (Float) -> Unit = {}) {
        out.parentFile?.mkdirs()
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA); c.connectTimeout = 15000; c.readTimeout = 60000
        val total = c.contentLengthLong
        val tmp = File(out.path + ".part")
        c.inputStream.use { i -> tmp.outputStream().use { o ->
            val buf = ByteArray(32768); var n: Int; var done = 0L
            while (i.read(buf).also { n = it } > 0) { o.write(buf, 0, n); done += n; if (total > 0) onProgress(done / total.toFloat()) }
        } }
        tmp.renameTo(out)
    }
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

class Paths(ctx: Context) {
    val root: File = ctx.getExternalFilesDir(null) ?: ctx.filesDir
    val versions = File(root, "versions")
    val runtimeLib = File(root, "runtime/lib")
    fun mods(version: String) = File(root, "instances/$version/mods").also { it.mkdirs() }
    fun gameDir(version: String) = File(root, "instances/$version").also { it.mkdirs() }
    fun jar(v: String) = File(versions, "$v/$v.jar")
    fun json(v: String) = File(versions, "$v/$v.json")
}

object VersionStore {
    fun list(p: Paths): List<String> =
        p.versions.listFiles()?.filter { it.isDirectory && File(it, "${it.name}.jar").exists() }?.map { it.name }?.sorted() ?: emptyList()

    /** Imports a zip containing a user-supplied version .jar and .json. */
    fun importZip(ctx: Context, p: Paths, uri: Uri): String {
        var jar: ByteArray? = null; var json: ByteArray? = null; var jarName = ""
        ctx.contentResolver.openInputStream(uri)!!.use { raw -> ZipInputStream(raw).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val n = e.name.substringAfterLast('/')
                if (n.endsWith(".jar")) { jar = z.readBytes(); jarName = n.removeSuffix(".jar") }
                else if (n.endsWith(".json")) json = z.readBytes()
            }
        } }
        val jarBytes = jar ?: error("No .jar found in zip")
        val id = json?.let { runCatching { JSONObject(String(it)).getString("id") }.getOrNull() } ?: jarName
        File(p.versions, id).mkdirs()
        p.jar(id).writeBytes(jarBytes)
        val j = json
        if (j != null) p.json(id).writeBytes(j)
        else p.json(id).writeText("{\"id\":\"$id\",\"mainClass\":\"net.minecraft.client.Minecraft\"}")
        return id
    }
}

object OfflineAccount {
    fun uuid(name: String): String = UUID.nameUUIDFromBytes("OfflinePlayer:$name".toByteArray()).toString()
}

enum class LoaderKind { CLEANROOM, RISUGAMI }
data class LoaderPlan(val kind: LoaderKind, val name: String, val url: String?)

object ModLoaders {
    fun kindFor(version: String) = if (version.startsWith("1.12")) LoaderKind.CLEANROOM else LoaderKind.RISUGAMI

    /** Cleanroom: latest GitHub release. Risugami's ModLoader: searched on Modrinth. */
    fun find(version: String): LoaderPlan {
        if (kindFor(version) == LoaderKind.CLEANROOM) {
            val j = JSONObject(Net.get("https://api.github.com/repos/CleanroomMC/Cleanroom/releases/latest"))
            val a = j.getJSONArray("assets")
            val asset = (0 until a.length()).map { a.getJSONObject(it) }
                .firstOrNull { it.getString("name").endsWith(".jar") && !it.getString("name").contains("sources") }
            return LoaderPlan(LoaderKind.CLEANROOM, "Cleanroom ${j.getString("tag_name")}", asset?.getString("browser_download_url"))
        }
        val facets = Net.enc("[[\"project_type:mod\"],[\"versions:$version\"]]")
        val hits = JSONObject(Net.get("https://api.modrinth.com/v2/search?query=modloader&limit=5&facets=$facets")).getJSONArray("hits")
        for (i in 0 until hits.length()) {
            val h = hits.getJSONObject(i)
            if (h.getString("title").contains("modloader", true))
                return LoaderPlan(LoaderKind.RISUGAMI, "Risugami's ModLoader", Modrinth.fileUrl(h.getString("project_id"), version))
        }
        return LoaderPlan(LoaderKind.RISUGAMI, "Risugami's ModLoader (not found online)", null)
    }

    fun install(p: Paths, version: String, plan: LoaderPlan, onProgress: (Float) -> Unit) {
        val url = plan.url ?: error("No download found online. Import the loader zip manually.")
        Net.download(url, File(p.gameDir(version), "loader/${url.substringAfterLast('/')}"), onProgress)
    }
}

data class Hit(val id: String, val title: String, val desc: String, val downloads: Long)

object Modrinth {
    fun search(q: String, version: String?): List<Hit> {
        val f = StringBuilder("[[\"project_type:mod\"]")
        if (!version.isNullOrBlank()) f.append(",[\"versions:$version\"]")
        f.append("]")
        val arr = JSONObject(Net.get("https://api.modrinth.com/v2/search?limit=25&query=${Net.enc(q)}&facets=${Net.enc(f.toString())}")).getJSONArray("hits")
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            Hit(it.getString("project_id"), it.getString("title"), it.getString("description"), it.optLong("downloads"))
        }
    }
    fun fileUrl(projectId: String, version: String): String? {
        val gv = Net.enc("[\"$version\"]")
        val arr = JSONArray(Net.get("https://api.modrinth.com/v2/project/$projectId/version?game_versions=$gv"))
        if (arr.length() == 0) return null
        return arr.getJSONObject(0).getJSONArray("files").getJSONObject(0).getString("url")
    }
    fun install(p: Paths, hit: Hit, version: String, onProgress: (Float) -> Unit): String {
        val url = fileUrl(hit.id, version) ?: error("No file for $version")
        val name = url.substringAfterLast('/')
        Net.download(url, File(p.mods(version), name), onProgress)
        return name
    }
}

data class Lib(val name: String, val url: String)

object RuntimeInstaller {
    private const val M = "https://repo1.maven.org/maven2"
    val libs = listOf(
        Lib("lwjgl 3.3.3", "$M/org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3.jar"),
        Lib("lwjgl-glfw 3.3.3", "$M/org/lwjgl/lwjgl-glfw/3.3.3/lwjgl-glfw-3.3.3.jar"),
        Lib("lwjgl-opengl 3.3.3", "$M/org/lwjgl/lwjgl-opengl/3.3.3/lwjgl-opengl-3.3.3.jar"),
        Lib("lwjgl-openal 3.3.3", "$M/org/lwjgl/lwjgl-openal/3.3.3/lwjgl-openal-3.3.3.jar"),
        Lib("lwjgl-stb 3.3.3", "$M/org/lwjgl/lwjgl-stb/3.3.3/lwjgl-stb-3.3.3.jar"),
        Lib("lwjgl 2.9.3 (legacy)", "$M/org/lwjgl/lwjgl/lwjgl/2.9.3/lwjgl-2.9.3.jar"),
        Lib("jinput", "$M/net/java/jinput/jinput/2.0.5/jinput-2.0.5.jar"),
        Lib("jopt-simple", "$M/net/sf/jopt-simple/jopt-simple/5.0.4/jopt-simple-5.0.4.jar"),
        Lib("gson", "$M/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar"),
        Lib("guava", "$M/com/google/guava/guava/31.1-jre/guava-31.1-jre.jar"),
        Lib("commons-io", "$M/commons-io/commons-io/2.11.0/commons-io-2.11.0.jar"),
        Lib("commons-lang3", "$M/org/apache/commons/commons-lang3/3.12.0/commons-lang3-3.12.0.jar"),
        Lib("commons-codec", "$M/commons-codec/commons-codec/1.15/commons-codec-1.15.jar"),
        Lib("log4j-api", "$M/org/apache/logging/log4j/log4j-api/2.17.1/log4j-api-2.17.1.jar"),
        Lib("log4j-core", "$M/org/apache/logging/log4j/log4j-core/2.17.1/log4j-core-2.17.1.jar"),
        Lib("netty-all", "$M/io/netty/netty-all/4.1.82.Final/netty-all-4.1.82.Final.jar"),
    )
    fun isInstalled(p: Paths, l: Lib) = File(p.runtimeLib, l.url.substringAfterLast('/')).exists()
    fun install(p: Paths, l: Lib, onProgress: (Float) -> Unit) =
        Net.download(l.url, File(p.runtimeLib, l.url.substringAfterLast('/')), onProgress)
}

/** Bridge to the PojavLauncher engine (native libs added by scripts/fetch_engine.sh). */
object Engine {
    val available: Boolean by lazy { runCatching { System.loadLibrary("pojavexec") }.isSuccess }

    fun buildArgs(p: Paths, version: String, user: String, ram: Int): List<String> {
        val meta = JSONObject(p.json(version).readText())
        val main = meta.optString("mainClass", "net.minecraft.client.Minecraft")
        val cp = (p.runtimeLib.listFiles()?.map { it.path } ?: emptyList()) + p.jar(version).path +
            (File(p.gameDir(version), "loader").listFiles()?.map { it.path } ?: emptyList())
        val game = p.gameDir(version).path
        return listOf("-Xmx${ram}M", "-cp", cp.joinToString(":"), main,
            "--username", user, "--version", version, "--gameDir", game, "--assetsDir", "$game/assets",
            "--uuid", OfflineAccount.uuid(user).replace("-", ""), "--accessToken", "0", "--userType", "legacy")
    }

    /**
     * Real Pojav startup chain (net.kdt.pojavlaunch.utils.JREUtils, then com.oracle.dalvik.VMLauncher):
     * relocateLibPath -> setJavaEnvironment -> initJavaRuntime -> setupExitMethod -> initializeHooks -> chdir -> launchJVM(String[]).
     * JREUtils signatures differ between Pojav forks, so setup steps are called by name with whatever args fit
     * (Context / String / File) and every step is logged. VMLauncher.launchJVM(String[]) is stable across forks.
     * Verify against the fork you vendor (scripts/fetch_engine.sh) and replace this with direct calls if you compile it in.
     */
    fun launch(ctx: android.content.Context, p: Paths, version: String, args: List<String>, log: (String) -> Unit): Result<Unit> = runCatching {
        check(available) { "Engine not installed. Run the workflow with 'with_engine' enabled (see README)." }
        val jre = Class.forName("net.kdt.pojavlaunch.utils.JREUtils")
        val home = File(ctx.filesDir, "runtimes/Internal").path
        val gameDir = p.gameDir(version).path
        for (step in listOf("relocateLibPath", "setJavaEnvironment", "initJavaRuntime", "setupExitMethod", "initializeHooks", "chdir")) {
            val m = jre.methods.firstOrNull { it.name == step }
            if (m == null) { log("skip $step (not in this fork)"); continue }
            val callArgs = m.parameterTypes.map { t ->
                when {
                    android.content.Context::class.java.isAssignableFrom(t) -> ctx
                    t == String::class.java -> if (step == "chdir") gameDir else home
                    t == File::class.java -> File(home)
                    else -> error("$step needs unsupported arg ${t.simpleName}; vendor the engine and call it directly")
                }
            }
            log("call $step"); m.invoke(null, *callArgs.toTypedArray())
        }
        val vm = Class.forName("com.oracle.dalvik.VMLauncher")
        val code = vm.getMethod("launchJVM", Array<String>::class.java).invoke(null, (listOf("java") + args).toTypedArray())
        log("JVM exited with code $code")
    }
}
