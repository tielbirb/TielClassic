# TielClassic
Created by **tielbirb**. A Minecraft: Java Edition launcher for Android, built on the **MojoLauncher** engine
(MojoLauncher is based on PojavLauncher). Runs infdev through modern versions.

## What you get
Everything in MojoLauncher (offline and Microsoft accounts, instances, Modrinth/CurseForge search and modpack install,
Forge, NeoForge, Fabric, Quilt, OptiFine, Better Than Adventure, custom controls, renderers, Java 8/17/21 runtimes) plus:
- **Cleanroom** (Minecraft 1.12.2) in the instance creator, installed from CleanroomMC's GitHub releases
- A **Credits** screen in the launcher menu
- TielClassic branding: app name and the cockatiel launcher icon

## Build
Push this repo to GitHub, then Actions -> **Build TielClassic** -> download the `TielClassic-debug` artifact (APK).
The workflow clones MojoLauncher (`v3_openjdk`), runs `scripts/apply_overlay.py`, and builds `:app_mojo:assembleFullDebug`
using the same Gradle/JDK versions as upstream's CI.
CurseForge search needs an API key: add a repository secret named `CURSEFORGE_API_KEY` (without it that source is disabled).
If upstream changes break an overlay anchor, the script stops with `overlay anchor not found`.

## Not done yet
- Risugami's ModLoader installer (infdev to Beta 1.7.3)
- Terracotta multiplayer (credited, not integrated)
- Cleanroom builds that require Java 25 will not run (the launcher ships Java 8, 17 and 21)
- Our own sleek UI: `prototype-compose/` is an unbuilt Jetpack Compose sketch; MojoLauncher's UI is Fragment/View based

## Your own game files
Never redistribute Mojang files. Use your own copy.

## License and credits
Contains MojoLauncher (LGPL-3.0), PojavLauncher (LGPL-3.0) and other components. Keep the license and offer source.
See CREDITS.md and NOTICE.
