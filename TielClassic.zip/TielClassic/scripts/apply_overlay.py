#!/usr/bin/env python3
"""Applies the TielClassic overlay to a MojoLauncher checkout. Fails loudly if an anchor is missing."""
import pathlib, re, shutil, sys

root = pathlib.Path(sys.argv[1]).resolve()
overlay = pathlib.Path(__file__).resolve().parent.parent / "overlay"
main = root / "app_mojo/src/main"
java = main / "java/git/artdeell/mojo"

def edit(path, fn, label):
    text = path.read_text(encoding="utf-8")
    new = fn(text)
    if new == text:
        sys.exit(f"overlay anchor not found: {label} ({path})")
    path.write_text(new, encoding="utf-8")
    print("patched", label)

def insert_after(anchor, addition):
    def f(t):
        i = t.find(anchor)
        return t if i < 0 else t[:i + len(anchor)] + addition + t[i + len(anchor):]
    return f

def insert_before(anchor, addition):
    def f(t):
        i = t.find(anchor)
        return t if i < 0 else t[:i] + addition + t[i:]
    return f

# 1. new files
for src in overlay.rglob("*"):
    if src.is_file():
        dst = root / src.relative_to(overlay)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print("added", dst.relative_to(root))

# 2. Cleanroom loader (GitHub releases list, Forge-style installer)
CLEANROOM_CLASS = '''
    private static class CleanroomUtils extends ForgelikeUtils {
        private static final String RELEASES_URL = "https://api.github.com/repos/CleanroomMC/Cleanroom/releases?per_page=100";

        public CleanroomUtils() {
            super(
                    "Cleanroom", "cleanroom", "forge", "%2$s",
                    RELEASES_URL,
                    "https://github.com/CleanroomMC/Cleanroom/releases/download/%1$s/cleanroom-%1$s-installer.jar",
                    false
            );
        }

        @Override
        public List<String> downloadVersions() throws IOException {
            try {
                return DownloadUtils.downloadStringCached(RELEASES_URL, "cleanroom_versions", input -> {
                    try {
                        com.google.gson.JsonArray releases = Tools.GLOBAL_GSON.fromJson(input, com.google.gson.JsonArray.class);
                        java.util.ArrayList<String> versions = new java.util.ArrayList<>();
                        for (com.google.gson.JsonElement element : releases) {
                            com.google.gson.JsonObject release = element.getAsJsonObject();
                            if (release.has("tag_name")) versions.add(release.get("tag_name").getAsString());
                        }
                        return versions;
                    } catch (RuntimeException e) {
                        throw new DownloadUtils.ParseException(e);
                    }
                });
            } catch (DownloadUtils.ParseException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        public InstanceInstaller createInstaller(String fullVersion) throws IOException {
            InstanceInstaller installer = new InstanceInstaller();
            installer.commandLineArgs = List.of("-Duser.language=en", "-Duser.country=US", "-javaagent:" + Tools.DIR_DATA + "/forge_installer/forge_installer.jar");
            installer.installerJar = new File(Tools.DIR_CACHE, "cleanroom-installer-" + fullVersion + ".jar").getAbsolutePath();
            installer.installerSha1 = null; // GitHub release assets ship no .sha1 file
            installer.installerDownloadUrl = getInstallerUrl(fullVersion);
            return installer;
        }

        @Override
        public String processVersionString(String version) {
            return "1.12.2";
        }

        @Override
        public boolean shouldSkipVersion(String version) {
            return false;
        }
    }
'''
def forgelike(t):
    t = insert_after("public static final ForgelikeUtils NEOFORGE_UTILS = new NeoforgeUtils();",
                     "\n    public static final ForgelikeUtils CLEANROOM_UTILS = new CleanroomUtils();")(t)
    i = t.rstrip().rfind("}")
    return t[:i] + CLEANROOM_CLASS + "}\n" if "CLEANROOM_UTILS" in t else t
edit(java / "modding/forge/ForgelikeUtils.java", forgelike, "ForgelikeUtils: Cleanroom")

edit(java / "fragments/ProfileTypeSelectFragment.java",
     insert_before("        view.findViewById(R.id.modded_profile_legacy_fabric)",
                   "        view.findViewById(R.id.modded_profile_cleanroom).setOnClickListener((v)->\n"
                   "                Tools.swapFragment(requireActivity(), CleanroomInstallFragment.class, CleanroomInstallFragment.TAG, null));\n"),
     "ProfileTypeSelectFragment: Cleanroom button")

def profile_layout(t):
    m = re.search(r'<com\.kdt\.mcgui\.MineButton\s+android:id="@\+id/modded_profile_modpack"', t)
    if not m: return t
    button = ('<com.kdt.mcgui.MineButton\n'
              '            android:id="@+id/modded_profile_cleanroom"\n'
              '            android:layout_width="match_parent"\n'
              '            android:layout_height="wrap_content"\n'
              '            android:layout_marginHorizontal="@dimen/padding_large"\n'
              '            android:layout_marginTop="@dimen/padding_large"\n'
              '            android:text="@string/modloader_dl_install_cleanroom_instance" />\n\n        ')
    return t[:m.start()] + button + t[m.start():]
edit(main / "res/layout/fragment_profile_type.xml", profile_layout, "profile layout: Cleanroom button")

# 3. Credits button in the launcher menu
def launcher_layout(t):
    anchor = "</androidx.constraintlayout.widget.ConstraintLayout>"
    i = t.find(anchor)
    if i < 0: return t
    button = ('<com.kdt.mcgui.LauncherMenuButton\n'
              '\t\t\t\tandroid:id="@+id/credits_button"\n'
              '\t\t\t\tstyle="@style/LauncherMenuButton.Universal"\n'
              '\t\t\t\tandroid:layout_width="match_parent"\n'
              '\t\t\t\tandroid:drawableStart="@drawable/ic_px_sharelog"\n'
              '\t\t\t\tandroid:text="@string/main_credits"\n'
              '\t\t\t\tapp:layout_constraintTop_toBottomOf="@id/open_files_button" />\n\t\t')
    return t[:i] + button + t[i:]
edit(main / "res/layout/fragment_launcher.xml", launcher_layout, "launcher layout: credits button")

edit(java / "fragments/MainMenuFragment.java",
     insert_after("Button mOpenDirectoryButton = view.findViewById(R.id.open_files_button);",
                  "\n        view.findViewById(R.id.credits_button).setOnClickListener(v -> git.artdeell.mojo.TielCredits.show(requireActivity()));"),
     "MainMenuFragment: credits click")

# 4. strings + branding (display name only; package id untouched)
def strings(t):
    t = re.sub(r'(<string name="app_short_name">)[^<]*(</string>)', r'\1TielClassic\2', t)
    add = ('    <string name="cleanroom_dl_select_version">Select Cleanroom version (Minecraft 1.12.2, needs Java 21+)</string>\n'
           '    <string name="cleanroom_dl_no_installer">Could not load the Cleanroom release list.</string>\n'
           '    <string name="modloader_dl_install_cleanroom_instance">Create Cleanroom instance (1.12.2)</string>\n'
           '    <string name="main_credits">Credits</string>\n')
    return t.replace("</resources>", add + "</resources>")
edit(main / "res/values/strings.xml", strings, "strings + app name")
print("overlay applied")
