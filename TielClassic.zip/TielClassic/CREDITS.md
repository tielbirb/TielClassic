# Credits

**TielClassic** is created by **tielbirb**.

## Engine
- **MojoLauncher** (https://github.com/MojoLauncher/MojoLauncher), LGPL-3.0. TielClassic's game engine and runtime are borrowed from it.
- **PojavLauncher** by the PojavLauncher Team (https://github.com/PojavLauncherTeam/PojavLauncher), LGPL-3.0, which MojoLauncher is based on.
- **Boardwalk** by zhuowei (https://github.com/zhuowei/Boardwalk), the origin of Pojav's JVM launcher.

## Multiplayer (planned, not integrated yet)
- **Terracotta** by **burningtnt** (https://github.com/burningtnt/Terracotta), Minecraft multiplayer built on EasyTier.
- **EasyTier** (https://github.com/EasyTier/EasyTier), the networking layer Terracotta uses.

## Components used by the engine (per the MojoLauncher README)
Holy GL4ES (MIT), OpenJDK (GPLv2+CE), GLFW (zlib), SDL / MojoSDL (zlib), LWJGL2-GLFW (BSD-3), LWJGL3 (BSD-3),
mojoexec (MIT), Mesa 3D (MIT), pro-grade (Apache-2.0), bhook (MIT), Authlib-Injector (AGPL-3.0),
OpenAL Soft (LGPL), oboe (Apache-2.0), Android Support Libraries (Apache-2.0).

## Services and projects
Modrinth, CurseForge, Cleanroom (CleanroomMC), Risugami's ModLoader, Better Than Adventure, The 1.12.2 Pack.

## App icon
Cockatiel icon supplied by tielbirb. Check the icon's original license and add its required attribution here if it has one.

## Not affiliated
TielClassic is not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang AB. Supply your own game files.
