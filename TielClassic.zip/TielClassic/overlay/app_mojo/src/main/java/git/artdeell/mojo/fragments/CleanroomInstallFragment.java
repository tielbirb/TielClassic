package git.artdeell.mojo.fragments;

import git.artdeell.mojo.R;
import git.artdeell.mojo.modding.forge.ForgelikeUtils;

public class CleanroomInstallFragment extends ForgelikeInstallFragment {
    public static final String TAG = "CleanroomInstallFragment";

    public CleanroomInstallFragment() {
        super(ForgelikeUtils.CLEANROOM_UTILS, TAG);
    }

    @Override
    public int getTitleText() {
        return R.string.cleanroom_dl_select_version;
    }

    @Override
    public int getNoDataMsg() {
        return R.string.cleanroom_dl_no_installer;
    }
}
