package git.artdeell.mojo;

import android.app.AlertDialog;
import android.content.Context;
import android.widget.ScrollView;
import android.widget.TextView;

/** Credits dialog shown from the launcher menu. */
public final class TielCredits {
    private static final String TEXT =
            "TielClassic\nCreated by tielbirb\n\n"
            + "Engine\n"
            + "- MojoLauncher (LGPL-3.0): github.com/MojoLauncher/MojoLauncher\n"
            + "- PojavLauncher Team (LGPL-3.0), the project MojoLauncher is based on\n"
            + "- Boardwalk by zhuowei\n\n"
            + "Multiplayer (planned)\n"
            + "- Terracotta by burningtnt, built on EasyTier\n\n"
            + "Mod loaders and content\n"
            + "- Cleanroom by CleanroomMC\n"
            + "- Modrinth and CurseForge\n"
            + "- Better Than Adventure\n\n"
            + "Engine components (see MojoLauncher's README for licenses)\n"
            + "Holy GL4ES, OpenJDK, GLFW, SDL, LWJGL, mojoexec, Mesa 3D, pro-grade, bhook, "
            + "Authlib-Injector, OpenAL Soft, oboe\n\n"
            + "Not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang AB.";

    private TielCredits() {}

    public static void show(Context context) {
        TextView view = new TextView(context);
        view.setText(TEXT);
        view.setPadding(48, 32, 48, 32);
        ScrollView scroll = new ScrollView(context);
        scroll.addView(view);
        new AlertDialog.Builder(context)
                .setTitle("Credits")
                .setView(scroll)
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}
